package com.example.hotel.controller;

import com.example.hotel.Main;

public class RaizController {
    Main main;
    public void setMain(Main main) {
        this.main = main;
    }
}
