package com.example.hotel.model;

public class ExcepcionPersona extends RuntimeException {
    public ExcepcionPersona(String message) {
        super(message);
    }
}
