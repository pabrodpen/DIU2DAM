package com.example.hotel.model;

public class ExcepcionReserva extends RuntimeException {
  public ExcepcionReserva(String message) {
    super(message);
  }
}
