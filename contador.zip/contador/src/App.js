import React, { Component /*, useState*/ } from "react";
import "./counterApp.css";

// COMPONENTE PRINCIPAL
class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      num: 0,
    };
  }

  // Métodos para manejar el estado del contador
  incrementar = () => {
    this.setState({ num: this.state.num + 1 });
  };

  decrementar = () => {
    this.setState({ num: this.state.num - 1 });
  };

  resetear = () => {
    this.setState({ num: 0 });
  };

  render() {
    return (
      <div className="container-counter">
        {/* Texto central del contador */}
        <div className="counter">{this.state.num}</div>
        {/* Botones */}
        <div className="buttons">
          <button className="incButton" onClick={this.incrementar}>
            Incrementar
          </button>
          <button className="incButton" onClick={this.decrementar}>
            Decrementar
          </button>
          <button className="incButton" onClick={this.resetear}>
            Resetear
          </button>
        </div>
      </div>
    );
  }
}

export default App;
