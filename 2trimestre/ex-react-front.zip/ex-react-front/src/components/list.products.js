import React, { Component } from "react";
import ProductDataService from "../services/product.service";
import { Link } from "react-router-dom";
import { Button, Form, FormGroup, Label, Input } from 'reactstrap';
import ProgressBar from "./progress.bar";

export default class ProductsList extends Component {
  constructor(props) {
    super(props);
    
    this.state = {
      products: [],
      currentProduct: null,
      currentIndex: -1,
    };
  }

  componentDidMount() {
    this.retrieveProducts();
  }

  retrieveProducts() {
    ProductDataService.getAll()
      .then(response => {
        this.setState({ products: response.data });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  refreshList() {
    this.retrieveProducts();
    this.setState({ currentProduct: null, currentIndex: -1 });
  }

  setActiveProduct(product, index) {
    this.setState({ currentProduct: product, currentIndex: index });
  }

  render() {
    const { products, currentProduct, currentIndex } = this.state;
    return (
      <div className="list row">
        <div className="col-md-6">
          <h4>Lista de Productos</h4>

          <ul className="list-group">
            {products &&
              products.map((product, index) => (
                <li
                  className={"list-group-item " + (index === currentIndex ? "active" : "")}
                  onClick={() => this.setActiveProduct(product, index)}
                  key={index}
                >
                  {product.name}
                </li>
              ))}
          </ul>
        </div>
        <div className="col-md-6">
          {currentProduct ? (
            <div>
              <h4>Detalles del Producto</h4>
              <p><strong>Nombre:</strong> {currentProduct.name}</p>
              <p><strong>Stock:</strong> {currentProduct.stock}</p>
              <p><strong>Precio:</strong> {currentProduct.price}</p>
              <p><strong>Marca:</strong> {currentProduct.brand}</p>
              <p><strong>Activo:</strong> {currentProduct.active ? "Sí" : "No"}</p>

              <Link to={`/products/${currentProduct.id}`} className="badge badge-warning">Editar</Link>

              <div className="mt-3">
                <ProgressBar />
              </div>
            </div>
          ) : (
            <div><p>Seleccione un producto...</p></div>
          )}
        </div>
      </div>
    );
  }
}
