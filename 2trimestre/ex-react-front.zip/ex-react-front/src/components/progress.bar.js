{/*import React, { useContext } from "react";

const ProgressBar = () => {
  const { numeroProducts, numeroMaximo } = useContext(ProductsContext);

  const progressPercentage = (numeroProducts / numeroMaximo) * 100;

  return (
    <div className="progress mt-3">
      <div
        className="progress-bar bg-success"
        role="progressbar"
        style={{ width: `${progressPercentage}%` }}
        aria-valuenow={numeroProducts}
        aria-valuemin="0"
        aria-valuemax={numeroMaximo}
      >
        {numeroProducts} / {numeroMaximo} Productos
      </div>
    </div>
  );
};

export default ProgressBar;*/}
